CAPRI AI (Android)
Build with Android Studio: open this folder, let Gradle sync, Run (or Build > Build APK).
No PC: upload this folder to a new GitHub repo (keep the .github folder), open the Actions tab,
run "Build APK", download the artifact "CapriAI-apk", unzip, install app-debug.apk (allow unknown apps).
First launch: Summon Capri, grant "Display over other apps", paste your Anthropic API key.
