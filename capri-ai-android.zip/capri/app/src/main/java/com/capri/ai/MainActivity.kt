package com.capri.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {
    private val p get() = getSharedPreferences("c", 0)
    private fun reload() { if (OverlayService.on) startService(Intent(this, OverlayService::class.java).setAction("reload")) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * d).toInt(), (48 * d).toInt(), (20 * d).toInt(), (24 * d).toInt()) }
        val root = ScrollView(this).apply { setBackgroundColor(0xFF07040D.toInt()); addView(col) }
        fun tv(t: String, sz: Float = 14f) = TextView(this).apply { text = t; setTextColor(0xFFFFE8F6.toInt()); textSize = sz; setPadding(0, (14 * d).toInt(), 0, (4 * d).toInt()) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun edit(k: String, def: String, pw: Boolean = false) = EditText(this).apply {
            setText(p.getString(k, def)); setTextColor(0xFFFFE8F6.toInt()); setSingleLine()
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { p.edit().putString(k, s.toString().trim()).apply(); reload() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        col.addView(tv("CAPRI AI", 28f))
        col.addView(btn("Summon Capri") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow “Display over other apps” for Capri AI, then come back and tap Summon.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else startForegroundService(Intent(this, OverlayService::class.java))
        })
        col.addView(btn("Despawn Capri") { stopService(Intent(this, OverlayService::class.java)) })
        col.addView(tv("Anthropic API key (stays on this phone)")); col.addView(edit("key", "", true))
        col.addView(tv("Size"))
        col.addView(SeekBar(this).apply {
            max = 230; progress = p.getInt("size", 150) - 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { p.edit().putInt("size", progress + 90).apply(); reload() }
            })
        })
        col.addView(tv("Capri color (hex)")); col.addView(edit("acc", "#ff2a8a"))
        col.addView(tv("Speech box color")); col.addView(edit("bub", "#12081f"))
        col.addView(tv("Speech text color")); col.addView(edit("txt", "#ffe8f6"))
        setContentView(root)
    }
}
