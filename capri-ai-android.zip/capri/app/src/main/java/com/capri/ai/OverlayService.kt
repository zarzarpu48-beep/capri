package com.capri.ai

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class OverlayService : Service() {
    companion object { var on = false }
    private lateinit var wm: WindowManager
    private var view: WebView? = null
    private lateinit var lp: LP
    private val d get() = resources.displayMetrics.density
    private val p get() = getSharedPreferences("c", 0)
    private val size get() = p.getInt("size", 150)
    private fun h(extra: Int) = ((size * 1.4 + 135 + extra) * d).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "Capri", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "c").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Capri is online")
            .addAction(Notification.Action.Builder(0, "Despawn", pi).build()).build()
        if (android.os.Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build(); on = true
        return START_STICKY
    }

    private fun build() {
        drop()
        val w = WebView(this).apply { setBackgroundColor(0); settings.javaScriptEnabled = true; addJavascriptInterface(Bridge(), "A") }
        w.loadDataWithBaseURL("https://capri.local/", assets.open("capri.html").bufferedReader().readText(), "text/html", "utf-8", null)
        lp = LP((240 * d).toInt(), h(0), LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = p.getInt("x", 60); lp.y = p.getInt("y", 400)
        wm.addView(w, lp); view = w
    }
    private fun drop() { view?.let { try { wm.removeView(it) } catch (e: Exception) {}; it.destroy() }; view = null }
    override fun onDestroy() { drop(); on = false; super.onDestroy() }

    inner class Bridge {
        @JavascriptInterface fun cfg(): String { val q = p; return JSONObject().put("size", size).put("acc", q.getString("acc", "#ff2a8a")).put("bub", q.getString("bub", "#12081f")).put("txt", q.getString("txt", "#ffe8f6")).put("key", q.getString("key", "")).toString() }
        @JavascriptInterface fun move(dx: Double, dy: Double) { view?.post {
            val m = resources.displayMetrics
            lp.x = (lp.x + dx * d).toInt().coerceIn(0, m.widthPixels - lp.width)
            lp.y = (lp.y + dy * d).toInt().coerceIn(0, m.heightPixels - lp.height)
            wm.updateViewLayout(view, lp); p.edit().putInt("x", lp.x).putInt("y", lp.y).apply() } }
        @JavascriptInterface fun input(open: Boolean) { view?.post {
            lp.flags = if (open) LP.FLAG_NOT_TOUCH_MODAL else LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL
            lp.softInputMode = LP.SOFT_INPUT_ADJUST_PAN
            lp.height = h(if (open) 56 else 0)
            lp.y = lp.y.coerceAtMost(resources.displayMetrics.heightPixels - lp.height - (if (open) (300 * d).toInt() else 0)).coerceAtLeast(0)
            wm.updateViewLayout(view, lp)
            if (open) view?.requestFocus() } }
    }
}
